<?php
session_start();
?>
<head>
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<table width="776" border="0" align="center" cellpadding="0" cellspacing="0" class="tableBorder">
  <tr>
    <td>
    <?php include("navigation.php");?>
	</td>
    </tr>
    <td>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td valign="top" bgcolor="#FFFFFF"><table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="tableBorder_gray">
      <tr>
        <td align="center" valign="top" style="padding:5px;"><table width="98%" border="0" cellpadding="0" cellspacing="0">
      <tr>
      <td height="22" valign="top" class="word_orange">当前位置:读者管理&gt;读者档案管理&gt;&gt;&gt;</td>
      </tr>
      <tr>
        <td align="center" valign="top">
<?php
include("conn/conn.php");
$sql=mysqli_query($conn,"select r.id,r.barcode,r.name,t.name as typename,r.paperType,r.paperNO,r.tel,r.email from tb_reader as r join (select * from tb_readertype)as t on r.typeid=t.id");
$info=mysqli_fetch_array($sql);
if($info==false){
?><table width="100%" height="30" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="36" align="center">暂无读者信息! </td>
        </tr>
        </table>
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
         <td>
           <a href="reader_add.php">添加读者信息</a></td>
           </tr>
           </table>
        <?php
}else{
	?><table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr height="30">
      <td width="87%">&nbsp;    </td>
    <td width="13%">
         <a href="reader_add.php">添加读者信息</a></td>
         </tr>
         </table>
     <table width="96%" border="1" cellpadding="0" bordercolor="#E1E1E1" style="border-collapse:collapse;">
     <tr height="30" align="center" bgcolor="#e3F4F7">
     <td width="13%">条形码</td>
     <td width="9%">姓名</td>
     <td width="11%">读者类型</td>
     <td width="10%">证件类型</td>
     <td width="18%">证件号码</td>
     <td width="13%">电话</td>
     <td width="15%">E-mail</td>
     <td colspan="2">操作</td>
    </tr>
   <?php
   do{
	   ?><tr>
       <td><?php echo $info['barcode'];?></td>
       <td><a href="reader_info.php?id=<?php echo $info['id'];?> "><?php echo $info['name'];?></a></td>
       <td><?php echo $info['typename'];?></td>
       <td align="center"><?php echo $info['paperType'];?></td>
       <td><?php echo $info['paperNO'];?></td>
       <td align="center"><?php echo $info['tel'];?></td>
       <td><?php echo $info['email'];?></td>
       <td width="6%" align="center"><a href="reader_modify.php?id=<?php echo $info['id'];?>">修改</a></td>
       <td width="5%" align="center"><a href="reader_del.php?id=<?php echo $info['id'];?>">删除</a></td>
       </tr>
       <?php
   }while($info=mysqli_fetch_array($sql));
 }
 ?></table></td>
 </tr>
 </table><?php include("copyright.php");?></td>
 </tr>
 </table>
 </td>
    </tr>
   </table>
</body>

           
 