<?php
header("content-type:text/html;charset=utf-8");
include("conn/conn.php");
$id=$_GET['id'];
$sql=mysqli_query($conn,"delete from tb_reader where id='$id'");
if($sql){
	echo "<script language=javascript>alert(' 读 者 信 息 删 除 成 功 !');window.location.href='reader.php';</script>";
	}
	else{
		echo "<script language=javascript>alert(' 读 者 信 息 删 除 失 败  !');window.location.href='reader.php';</script>";
	}
?>