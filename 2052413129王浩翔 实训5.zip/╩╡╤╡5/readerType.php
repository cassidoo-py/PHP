<?php session_start();?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf_8">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<table width="776" border="0" align="center" cellpadding="0" cellspacing="0" class="tableBorder">
 <tr>
   <td>
   <?php include("navigation.php");?>
   </td>
 </tr>
 <td>
 <table width="100%" border="0"  cellspacing="0" cecellpadding="0">
 <tr>
   <td valign="top" bgcolor="#FFFFFF"><table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="tableBorder_gray">
   <tr>
     <td valign="top" style="padding:5px;"><table width="98%" border="0" cellpadding="0" cellspacing="0">
   <tr>
      <td height="22" valign="top" class="word_orange">当前位置：读者管理 &gt;读者类型管理 &gt;&gt;&gt;</td>
    </tr>
    <tr>
      <td align="center" valign="top">
<?php
include("conn/conn.php");
$sql=mysqli_query($conn,"select*from tb_readertype");
$info=mysqli_fetch_array($sql);
if($info==false){
?>
  <table width="100%" height="30" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="36" align="center">暂无读者类型信息!</td>
  </tr>
  </table>
<?php
}else{
?>
<table width="91%" border="0"  cellspacing="0" cellpadding="0">
  <tr height="30">
   <td align="right">
     <a href="#" onClick="window.open('readerType_add.php','','width=340,height=215')">添加读者类型信息</a></td>
  </tr>
  </table>
   <table width="91%" border="1" cellpadding="0" cellspacing="0" bordercolor="#FFFFFF" bordercolordark="#D2E3E6" bordercolorlight="#FFFFFF">
       <tr height="30" align="center" bgcolor="#e3F4F7">
   <td width="35%">读者类型名称</td>
   <td width="35%">可借数量</td>
   <td width="14%">删除</td>
  </tr>
<?php
do{
?>
  <tr>
   <td style="padding-left:130px;"><?php echo $info['name'];?></td>
   <td align="center"><?php echo $info['number'];?></td>
   <td align="center"><a href="readerType_del.php?id=<?php echo $info['id'];?>"> 删 除 </a></td>
   </tr>
<?php
}while($info=mysqli_fetch_array($sql));}
?>
</table></td>
 </tr>
 </table>
 </td>
 </tr>
 </table><?php include("copyright.php")?></td>
 </tr>
 </table>
 </td>
 </tr>
</table>
</body>
</html>

     