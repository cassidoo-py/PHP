<?php
header("content-type:text/html;charset=utf-8");
include("conn/conn.php");
date_default_timezone_set("PRC");
if($_POST['Submit']!=""){
$name=$_POST['name'];
$sex=$_POST['sex'];
$barcode=$_POST['barcode'];
$typeid=$_POST['typeid'];
$vocation=$_POST['vocation'];
$birthday=$_POST['birthday'];
$paperType=$_POST['paperType'];
$paperNO=$_POST['paperNO'];
$tel=$_POST['tel'];
$email=$_POST['email'];
$createDate=date("Y-m-d");
$operator=$_POST['operator'];
$remark=$_POST['remark'];
$sql=mysqli_query($conn,"insert into tb_reader(name,sex,barcode,typeid,vocation,birthday,paperType,paperNO,tel,email,createDate,operator,remark) 
values('$name','$sex','$barcode','$typeid','$vocation','$birthday','$paperType','$paperNO','$tel','$email','$createDate','$operator','$remark')");
if($sql==true){
	echo "<script  language=javascript>alert(' 读 者 信 息 添 加 成 功 !');
    location.href='Reader.php';
    </script>";
} else{
    echo "<script  language=javascript>alert(' 读 者 信 息 添 加 失 败  !');
    history.back();window.opener.location.reload();
    </script>";
}
}
?>